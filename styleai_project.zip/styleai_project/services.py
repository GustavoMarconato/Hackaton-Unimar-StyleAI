import pywhatkit as kit
import time
import re

def limpar_numero(tel):
    # Remove parênteses, traços e espaços, mantendo o +
    return re.sub(r'[^\d+]', '', tel)

def disparar_em_massa(lista_contatos, mensagens):
    # lista_contatos: lista de números formatados
    # mensagens: lista de textos gerados pela IA
    for num, msg in zip(lista_contatos, mensagens):
        num_limpo = limpar_numero(num)
        # Envia instantaneamente (abre aba, cola e envia)
        kit.sendwhatmsg_instantly(num_limpo, msg, wait_time=10, tab_close=True)
        time.sleep(2) # Intervalo de segurança para não travar o navegador