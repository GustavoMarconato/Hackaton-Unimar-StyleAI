import google.generativeai as genai

# Configure sua chave aqui
genai.configure(api_key="SUA_CHAVE_GEMINI_AQUI")

def gerar_mensagem(tipo, nome, valor=None, peca=None):
    model = genai.GenerativeModel('gemini-1.5-flash')
    
    if tipo == "cobranca":
        prompt = f"Escreva uma mensagem curta e gentil de WhatsApp para {nome} sobre um débito de R${valor}. Use emojis."
    else:
        prompt = f"Crie uma oferta curta para {nome} sobre a peça {peca} que está em promoção. Seja persuasivo."
    
    try:
        response = model.generate_content(prompt)
        return response.text
    except:
        return "Olá! Temos uma novidade para você na loja. Confira!"