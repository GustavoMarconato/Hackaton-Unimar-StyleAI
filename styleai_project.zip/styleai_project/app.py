import streamlit as st
from database import init_db, query_db, execute_db
from ai_logic import gerar_mensagem
from services import disparar_em_massa

# Configuração da página e Estilo Visual
st.set_page_config(page_title="StyleAI Enterprise v2", layout="wide", page_icon="👔")
init_db()

# Custom CSS para melhorar a interface
st.markdown("""
    <style>
    .stMetric { background-color: #f0f2f6; padding: 10px; border-radius: 10px; }
    .stButton>button { width: 100%; border-radius: 5px; height: 3em; background-color: #007bff; color: white; }
    </style>
    """, unsafe_allow_html=True)

st.sidebar.title("🏢 StyleAI Panel")
aba = st.sidebar.radio("Navegar", ["Dashboard", "Cadastrar Clientes", "Estoque/Promoções", "Central de Cobrança"])

# --- ABA: CADASTRAR CLIENTES ---
if aba == "Cadastrar Clientes":
    st.header("👤 Cadastro de Clientes")
    with st.form("new_client"):
        col1, col2 = st.columns(2)
        nome = col1.text_input("Nome")
        cpf = col1.text_input("CPF")
        tel = col2.text_input("WhatsApp (Ex: +55 (11) 99999-9999)")
        gen = col2.selectbox("Gênero", ["Masculino", "Feminino"])
        divida = st.number_input("Valor da Dívida Atual (Fiado)", min_value=0.0)
        
        if st.form_submit_button("Salvar no Banco de Dados"):
            status = "Atrasado" if divida > 0 else "Em dia"
            execute_db("INSERT INTO clientes (nome, cpf, telefone, genero, status, divida) VALUES (?,?,?,?,?,?)",
                       (nome, cpf, tel, gen, status, divida))
            st.success(f"Cliente {nome} cadastrado com sucesso!")

# --- ABA: ESTOQUE/PROMOÇÕES ---
elif aba == "Estoque/Promoções":
    st.header("👗 Gestão de Estoque e Marketing")
    
    with st.expander("➕ Adicionar Nova Peça em Promoção"):
        with st.form("new_item"):
            peca = st.text_input("Nome da Roupa")
            cat = st.selectbox("Público-Alvo", ["Masculino", "Feminino"])
            preco = st.number_input("Preço Promocional", min_value=0.0)
            if st.form_submit_button("Cadastrar e Preparar Campanha"):
                execute_db("INSERT INTO estoque (peca, categoria, preco, promocao) VALUES (?,?,?,?)",
                           (peca, cat, preco, "Sim"))
                st.success(f"{peca} adicionada às promoções!")
    
    st.subheader("📢 Disparar Ofertas para Clientes")
    promo_itens = query_db("SELECT * FROM estoque WHERE promocao = 'Sim'")
    
    if not promo_itens.empty:
        item_sel = st.selectbox("Selecione o item para promover:", promo_itens['peca'])
        categoria_item = promo_itens[promo_itens['peca'] == item_sel]['categoria'].values[0]
        
        if st.button(f"🚀 Enviar Oferta de {item_sel} para Público {categoria_item}"):
            # Filtra apenas clientes do gênero correspondente
            alvos = query_db("SELECT * FROM clientes WHERE genero = ?", (categoria_item,))
            
            if not alvos.empty:
                progresso = st.progress(0)
                contatos, mensagens = [], []
                for i, row in alvos.iterrows():
                    msg = gerar_mensagem("oferta", row['nome'], peca=item_sel)
                    contatos.append(row['telefone'])
                    mensagens.append(msg)
                    progresso.progress((i + 1) / len(alvos))
                
                disparar_em_massa(contatos, mensagens)
                st.success(f"Ofertas enviadas para {len(alvos)} clientes {categoria_item}!")
            else:
                st.warning("Nenhum cliente cadastrado para este gênero.")
    else:
        st.info("Nenhuma peça em promoção cadastrada.")

# --- ABA: CENTRAL DE COBRANÇA ---
elif aba == "Central de Cobrança":
    st.header("🤖 Automação de Cobrança em Massa")
    devedores = query_db("SELECT * FROM clientes WHERE status = 'Atrasado'")
    
    col1, col2 = st.columns([1, 3])
    col1.metric("Inadimplentes", len(devedores))
    
    if not devedores.empty:
        st.dataframe(devedores, use_container_width=True)
        if st.button("🚀 INICIAR COBRANÇA AUTOMÁTICA (Todos da Lista)"):
            progresso = st.progress(0)
            contatos, mensagens = [], []
            
            st.write("IA redigindo mensagens personalizadas...")
            for i, row in devedores.iterrows():
                msg = gerar_mensagem("cobranca", row['nome'], valor=row['divida'])
                contatos.append(row['telefone'])
                mensagens.append(msg)
                progresso.progress((i + 1) / len(devedores))
            
            st.warning("Iniciando disparos. Não feche o navegador.")
            disparar_em_massa(contatos, mensagens)
            st.success("Cobranças enviadas!")
    else:
        st.success("Tudo em dia! Nenhum cliente deve no momento.")

# --- ABA: DASHBOARD ---
elif aba == "Dashboard":
    st.header("📊 Visão Geral do Negócio")
    
    # Correção do erro de NoneType (TypeError)
    res_divida = query_db("SELECT SUM(divida) as total FROM clientes")
    total_divida = res_divida['total'][0] if res_divida['total'][0] is not None else 0.0
    
    col1, col2 = st.columns(2)
    col1.metric("Total a Receber (Fiado)", f"R$ {total_divida:.2f}")
    
    inadimplentes_count = len(query_db("SELECT * FROM clientes WHERE status='Atrasado'"))
    col2.metric("Clientes em Atraso", inadimplentes_count)
    
    st.divider()
    st.subheader("💡 Recomendações da IA")
    if total_divida > 0:
        st.error(f"Alerta: Você tem R$ {total_divida:.2f} parados. Recomendamos rodar a Central de Cobrança.")
    else:
        st.success("Saúde financeira excelente! Que tal lançar uma nova promoção?")