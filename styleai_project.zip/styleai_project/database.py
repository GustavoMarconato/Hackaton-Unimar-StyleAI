import sqlite3
import pandas as pd

def init_db():
    conn = sqlite3.connect('loja_master.db')
    c = conn.cursor()
    # Tabela de Clientes
    c.execute('''CREATE TABLE IF NOT EXISTS clientes 
                 (id INTEGER PRIMARY KEY, nome TEXT, cpf TEXT, telefone TEXT, 
                  genero TEXT, status TEXT, divida REAL)''')
    # Tabela de Produtos/Roupas
    c.execute('''CREATE TABLE IF NOT EXISTS estoque 
                 (id INTEGER PRIMARY KEY, peca TEXT, categoria TEXT, preco REAL, promocao TEXT)''')
    conn.commit()
    conn.close()

def query_db(sql, params=()):
    conn = sqlite3.connect('loja_master.db')
    df = pd.read_sql_query(sql, conn, params=params)
    conn.close()
    return df

def execute_db(sql, params=()):
    conn = sqlite3.connect('loja_master.db')
    c = conn.cursor()
    c.execute(sql, params)
    conn.commit()
    conn.close()